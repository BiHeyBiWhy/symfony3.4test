<?php

require __DIR__ . '/vendor/autoload.php';
$Jojo = new \Hetic\Human(80);

$Jojo->seeWeight();

$Jojo->setweight(70);

$juaneli = new \Hetic\Eleve('Le Cuit' , 'Jan Aili');
$jonathan = new \Hetic\Eleve('Gossait' , 'Jaune Attends' );